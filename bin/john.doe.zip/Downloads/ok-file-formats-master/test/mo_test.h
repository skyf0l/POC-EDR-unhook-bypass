#ifndef MO_TEST_H
#define MO_TEST_H

#include <stdbool.h>

int gettext_test(const char *path_to_gettext_files, bool verbose);

#endif
