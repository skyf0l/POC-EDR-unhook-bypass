#ifndef WAV_TEST_H
#define WAV_TEST_H

#include <stdbool.h>

int wav_test(const char *path_to_wav_files, bool verbose);

#endif
