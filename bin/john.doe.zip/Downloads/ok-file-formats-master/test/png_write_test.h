#ifndef PNG_WRITE_TEST_H
#define PNG_WRITE_TEST_H

#include <stdbool.h>

int png_write_test(bool verbose);

#endif
