#ifndef CSV_TEST_H
#define CSV_TEST_H

#include <stdbool.h>

int csv_test(const char *path_to_csv_files, bool verbose);

#endif
